﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Rst : MonoBehaviour
{
    public Button RestartButton;
    // Start is called before the first frame update
    void Start()
    {
        Button RstBtn = RestartButton.GetComponent<Button>();
        RstBtn.onClick.AddListener(Restart);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void Restart()
    {
        SceneManager.LoadScene("Level1");
    }
}

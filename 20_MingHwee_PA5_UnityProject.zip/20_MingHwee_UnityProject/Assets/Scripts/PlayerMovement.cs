﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerMovement : MonoBehaviour
{
    public float Speed = 50;
    Rigidbody PlayerRigidBody;
    public float CoinTaken = 0;
    // Start is called before the first frame update
    void Start()
    {
        PlayerRigidBody = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(moveHorizontal, 0, moveVertical);
        PlayerRigidBody.AddForce(movement * Speed * Time.deltaTime);

        if(CoinTaken == 4)                      //Next Level
        {
            SceneManager.LoadScene("Win");
        }

    }

   public void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.tag == "Coin")
        {
            CoinTaken += 1;
            Destroy(other.gameObject);
            GameManager.thismanager.UpdateScore();
        }

        if(other.gameObject.tag == "Hazard")
        {
            SceneManager.LoadScene("Lose");
        }
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class GameManager : MonoBehaviour
{
    public static GameManager thismanager;
    public float Score = 0;
    public Text Txt_Score;

    // Start is called before the first frame update
    void Start()
    {
        thismanager = this;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void UpdateScore()
    {
        Score += 10;
        Txt_Score.text = "Score: " + Score;


    }
}
